﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AutomationQlahsVksndtcWindowsFormsApp
{
    class HomePage:Page
    {
        
        public HomePage()
        {
            url = "http://qlahs.vksndtc.gov.vn/QLA/faces/homepage.jsf";
           
        }


        
    }
}
