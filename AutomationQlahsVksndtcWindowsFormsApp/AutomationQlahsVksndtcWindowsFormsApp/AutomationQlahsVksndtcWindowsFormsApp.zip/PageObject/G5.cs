﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AutomationQlahsVksndtcWindowsFormsApp.PageObjects
{
    class G5:G3
    {
        public G5() : base()
        {
            this.url = "http://qlahs.vksndtc.gov.vn/QLA/faces/hs/UpdateInfo/search_G5.jsf";
        }
    }
}
