﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AutomationQlahsVksndtcWindowsFormsApp.PageObjects
{
    class G4 : G3
    {
        public G4() : base()
        {
            this.url = "http://qlahs.vksndtc.gov.vn/QLA/faces/hs/UpdateInfo/search_G4.jsf";
        }
    }
}
