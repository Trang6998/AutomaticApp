﻿using AutomationQlahsVksndtcWindowsFormsApp.Resources;
using Newtonsoft.Json.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutomationQlahsVksndtcWindowsFormsApp
{

    class TaoMoiVuAnPopUp :Page
    {
        #region Controls definition  
        TextBox quyetĐinhKhoiToVuAnSo;
        TextBox dieuLuatVu;
        DateTimePicker ngayQuyetDinhKhoiToVuAn;
        Other ngayQd;
        Other ngayQdMot;
        Other toiVuKhong;
        ComboBox coQuanRaQuyetDinh;
        Other coQuanCongAn;
        TextBox donViRaQuyetDinh;
        TextBox tenVuAn;
        TextBox maVuCuaToaAn;
        ComboBox loaiToiPhamB;
        CheckBox loaiToiPhamC;
        DateTimePicker ngayXayRa;
        TextBox txtNgayXayRa;
        TextBox thang;
        TextBox nam;
        TextBox gio;
        TextBox noiXayRa;
        TextBox chiTietNoiXayRa;
        TextBox diaChiLuuTruHoSo;
        TextBox ghiChu;
        TextBox ngayQDKhoiToTuNgayText, ngayQDKhoiToDenNgayText, txtNgayQDKhoiToVuAn;

        CheckBox ghiAmGhiHinhBiMat;
        CheckBox ngheDienThoaiBiMat;
        CheckBox thuThapBiMatDuLieuDienTu;

        Button ghiLai;
        Button quayLai;

        Other o;
        #endregion
        Xpath x;
        

        public TaoMoiVuAnPopUp()
        {
            x = new Xpath();    
            #region Controls initialize  
            quyetĐinhKhoiToVuAnSo = new TextBox("quyết định khởi tố vụ án số",x.D["inputQuyetDinhKhoiToVuAnSo"],"");
            ngayQuyetDinhKhoiToVuAn = new DateTimePicker("chọn ngày", x.D["buttonNgayQuyetDinhKhoiToVuAn"], "");
            ngayQdMot = new Other("ngày 1", x.D["ngayMot"], "");
            ngayQd = new Other("chọn ngày", x.D["Ngay15QuyetDinhKhoiToVuAn"], "");
            coQuanRaQuyetDinh = new ComboBox("cơ quan ra QĐ", x.D["dropdownCoQuanRaQuyetDinh"], "");
            coQuanCongAn = new Other("cơ quan công an", x.D["coQuanCongAn"], "");
            dieuLuatVu = new TextBox("điều luật vụ", x.D["inputDieuLuatVu"], "");
            toiVuKhong = new Other("tội vu khống", x.D["toiVuKhong"], "");
            donViRaQuyetDinh = new TextBox("đơn vị ra QĐ", x.D["inputDonViRaQuyetDinh"], ""); 
            tenVuAn = new TextBox("tên vụ án", x.D["inputTenVuAn"], ""); 
            maVuCuaToaAn = new TextBox("mã vụ của tòa án", x.D["inputMaVuCuaToaAn"], "");
            loaiToiPhamB = new ComboBox("loại tội phạm check", x.D["checkBLoaiToiPham"], "");
            loaiToiPhamC = new CheckBox();
            txtNgayXayRa = new TextBox("ngày xảy ra", x.D["txtNgayXayRa"], "");
            ngayXayRa = new DateTimePicker("ngày xảy ra", x.D["inputThang"], "");
            thang = new TextBox("tháng", x.D["inputThang"], "");
            nam = new TextBox("năm", x.D["inputNam"], "");
            gio = new TextBox("giờ", x.D["inputGio"], "");
            noiXayRa = new TextBox("nơi xảy ra", x.D["inputNoiXayRa"], "");
            chiTietNoiXayRa = new TextBox("chi tiết nơi xảy ra", x.D["inputChiTietNoiXayRa"], "");
            diaChiLuuTruHoSo = new TextBox("địa chỉ lưu hồ sơ", x.D["inputDiaChiLuuTruHoSo"], "");
            ghiChu = new TextBox("ghi chú", x.D["inputGhiChu"], "");

            ghiAmGhiHinhBiMat = new CheckBox();
            ngheDienThoaiBiMat = new CheckBox();
            thuThapBiMatDuLieuDienTu = new CheckBox();

            ghiLai = new Button("buttonGhiLai", x.D["buttonGhiLai"], "");
            quayLai = new Button("buttonQuayLai", x.D["buttonQuayLai"], "");
            ngayQDKhoiToTuNgayText = new TextBox("txt ngày quyết định khởi tố", x.D["ngayQDKhoiToTuNgayText"], "");
            ngayQDKhoiToDenNgayText = new TextBox("txt ngày quyết định khởi tố", x.D["ngayQDKhoiToDenNgayText"], "");
            txtNgayQDKhoiToVuAn = new TextBox("text ngày quyết định khởi tố vụ án", x.D["txtNgayQDKhoiToVuAn"], "");
            o = new Other();

         
            #endregion
            //x = new Xpath();
            //this.driver = driver; 
        }

        public void DienThongTin(JObject jVuAn)
        {

            string s = jVuAn["txtNgayXayRa"].ToString();

            SendKeys(jVuAn["quyetĐinhKhoiToVuAnSo"].ToString(), quyetĐinhKhoiToVuAnSo);
            Click(txtNgayQDKhoiToVuAn);
            SendKeys(jVuAn["txtNgayQDKhoiToVuAn"].ToString(), txtNgayQDKhoiToVuAn);
            //Click(ngayQuyetDinhKhoiToVuAn);
            //SendKeys("01102019", ngayQuyetDinhKhoiToVuAn);
            //Click(ngayQdMot);
            //Click(coQuanRaQuyetDinh);
            //SendKeys("C", coQuanRaQuyetDinh);
            //SendKeys(Keys.Down, coQuanRaQuyetDinh);
            //SendKeys(Keys.Enter, coQuanRaQuyetDinh);
            //Click(coQuanCongAn);
            SendKeys(jVuAn["dieuLuatVu"].ToString(), dieuLuatVu);
            SendKeys(Keys.Enter, dieuLuatVu);
            
            SendKeys(jVuAn["donViRaQuyetDinh"].ToString(), donViRaQuyetDinh);
            SendKeys(Keys.Enter, donViRaQuyetDinh);
            Click(tenVuAn);
            SendKeys(jVuAn["tenVuAn"].ToString(), tenVuAn);
            //SendKeys(jVuAn["maVuCuaToaAn"].ToString(), maVuCuaToaAn);
            Click(loaiToiPhamB);
            //Click(loaiToiPhamC);

            //SendKeys(jVuAn["txtNgayXayRa"].ToString(),txtNgayXayRa);
            Click(txtNgayXayRa);
            
            SendKeys(jVuAn["txtNgayXayRa"].ToString(), txtNgayXayRa);
            if (jVuAn["txtNgayXayRa"].ToString().Contains("null") || s.Equals(""))
            {
                Click(nam);
                SendKeys("2019", nam); //thay bang send key txtNgayXayRa

            }
            //SendKeys(jVuAn["thang"].ToString(), thang);
            //SendKeys(jVuAn["gio"].ToString(), gio);
            //
            Clear(noiXayRa);
            SendKeys(jVuAn["noiXayRa"].ToString(), noiXayRa);
            SendKeys(Keys.Enter, noiXayRa);
            //SendKeys(jVuAn["chiTietNoiXayRa"].ToString(), chiTietNoiXayRa);
            SendKeys(jVuAn["diaChiLuuTruHoSo"].ToString(), diaChiLuuTruHoSo);
            SendKeys(jVuAn["ghiChu"].ToString(), ghiChu);

            Sleep();
            Sleep();

            Click(ghiLai);
            Sleep();
            JToken[] ts = jVuAn["DieuLuatKhoiToVuAn"].ToArray();
            foreach(JToken jToken in ts)
            {
                SendKeys((string)jToken["NoiDung"], new TextBox(
                    "toi danh", xpath.D["bsdlToiDanh"], ""
                ));
                SendKeys(Keys.Enter, new TextBox(
                    "toi danh", xpath.D["bsdlToiDanh"], ""
                ));
                Click(new Button("ghi lai dieu luat",xpath.D["bsdlGhiLaiDieuLuat"],""));
                Sleep();
                // 		ghi lai dieu luat
            }
             
            Click(quayLai);
            Sleep();
            Sleep();
             
        }
    }
}




//SendKeys("QD khởi tố VA số 1", By.Id("bodyForm:casebeginSetnum"));
//Click(By.XPath("//*[@id='bodyForm:casebeginIndate']/button"));
//Click(By.XPath("//*[@id='ui-datepicker-div']/table/tbody/tr[1]/td[3]/a"));
//SendKeys("1", By.Id("bodyForm:lawcode_input"));
//wait(3);
//chromeDriver.FindElement(By.Id("bodyForm:lawcode_input")).SendKeys(Keys.Enter);
//SendKeys("1", By.Id("bodyForm:casesppspcid2_input"));
//Click(By.XPath("//*[@id='bodyForm:casesppspcid2_panel']/ul/li[1]"));
//SendKeys("vụ án số 1", By.Id("bodyForm:casecasename"));
//Click(By.XPath("//*[@id='bodyForm:casecrimdate']/button"));
//Click(By.XPath("//*[@id='ui-datepicker-div']/table/tbody/tr[1]/td[3]/a"));
//chromeDriver.FindElement(By.Id("bodyForm:casecrimwhere_input")).Clear();
//SendKeys("01", By.Id("bodyForm:casecrimwhere_input"));
//wait(3);
//chromeDriver.FindElement(By.Id("bodyForm:casecrimwhere_input")).SendKeys(Keys.Enter);
//wait(3);
//SendKeys("Thành Công", By.Id("bodyForm:casecrimwhere1"));
//SendKeys("Q.Ba Đình -TP.Hà Nội", By.Id("bodyForm:caseaddress"));
//SendKeys("Thành Công", By.Id("bodyForm:caseremark"));
//Click(By.Id("bodyForm:case_ghihinh"));
//Click(By.Id("bodyForm:j_idt1087"));
//wait(3);
//chromeDriver.Navigate().GoToUrl("http://qlahs.vksndtc.gov.vn/QLA/faces/hs/UpdateInfo/search.jsf");//
//SendKeys("vụ án số 1", By.Id("bodyForm:casename"));
//Click(By.Id("bodyForm:btnSearch"));
//Click(By.XPath("//*[@id='bodyForm:resultTable_data']/tr"));
//Click(By.Id("bodyForm:j_idt266"));
//Click(By.Id("bodyForm:j_idt341"));