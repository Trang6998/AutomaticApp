using AutomationQlahsVksndtcWindowsFormsApp.Resources;
using Newtonsoft.Json.Linq;
using OpenQA.Selenium;

namespace AutomationQlahsVksndtcWindowsFormsApp.PageObject
{
    class QuyetDinhBiCan : Page
    {
        Button edit, add, qdBiCan;
        TextBox quyetDinhSo;
        TextBox ngay;

        TextBox vienKiemSat;

        TextBox hieuLuc;

        TextBox nguoiKy;

        TextBox chucVu;
        Button tenCoQuan;
        Button tenDonVi;
        Button loai;
        TextBox loaiFilter;
        TextBox loaiCT;
        Button save;
        Button back;
        Button backFromBiCan;

        public QuyetDinhBiCan()
        {
            url = "http://qlahs.vksndtc.gov.vn/QLA/faces/hs/UpdateInfo/update.jsf";
            edit = new Button("edit", xpath.D["bcEdit"], "");
            add = new Button("add", xpath.D["addQdBc"], "");
            qdBiCan = new Button("qdBiCan", xpath.D["qdBiCan"], "");

            quyetDinhSo = new TextBox("Quyết định số", xpath.D["qdBcSoQuyetDinh"], "");
            ngay = new TextBox("Ngày", xpath.D["qdBcNgayRaQuyetDinh"], "");
            //hieuLuc = new TextBox("Hiệu Lực", xpath.D["qdBcHieuLuc"], "");
            nguoiKy = new TextBox("người ký", xpath.D["qdBcTenNguoiKy"], "");
            tenCoQuan = new Button("tên cơ quan", xpath.D["qdBcTenCoQuan"], "");
            tenDonVi = new Button("tên đơn vị", xpath.D["qdBcTenDonVi"], "");
            loai = new Button("loại", xpath.D["qdBcTenloai"], "");
            loaiFilter = new TextBox("loai filter", xpath.D["qdBcTenloaiFilter"], "");
            loaiCT = new TextBox("loại ct", xpath.D["qdBcTenloaiCT"], "");
            save = new Button("ghi lại", xpath.D["qdBcSave"], "");
            chucVu = new TextBox("chức vụ", xpath.D["qdBcTenChucVi"], "");
            back = new Button("quay lại", xpath.D["qdBcBack"], "");
            backFromBiCan = new Button("quay lại từ bị can", xpath.D["bcBack"], "");
           

        }
        public void FillForm(JObject obj)
        {
            //Click(edit);
            //Sleep();
            //Click(add);
            Click(qdBiCan);
            Click(quyetDinhSo);
            SendKeys(obj["qdBcSoQuyetDinh"].ToString(), quyetDinhSo);
            Click(ngay);
            SendKeys(obj["qdBcNgayRaQuyetDinh"].ToString(), ngay);

            //SendKeys(obj["qdBcHieuLuc"].ToString(), hieuLuc);
            Click(nguoiKy);
            string g = obj["qdBcTenChucVu"].ToString();
            SendKeys(obj["qdBcTenNguoiKy"].ToString(), nguoiKy);
            SendKeys(Keys.Enter, nguoiKy);
            Click(chucVu);
            g = obj["qdBcTenChucVu"].ToString();
            SendKeys(obj["qdBcTenChucVu"].ToString(), chucVu);
            SendKeys(Keys.Enter, chucVu);
            //Click(tenCoQuan);
            //Click(tenDonVi);
            Click(loai);
            SendKeys(obj["qdBcTenloaiCT"].ToString(), loaiFilter);
            Click(loaiCT);
            //g = obj["qdBcTenloaiCT"].ToString();
            //SendKeys(obj["qdBcTenloaiCT"].ToString(), loaiCT);
            Click(save);
            Sleep();
            Click(back);
            Sleep();
            Click(backFromBiCan);
            Sleep();


        }
    }
}