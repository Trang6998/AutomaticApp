﻿using AutomationQlahsVksndtcWindowsFormsApp.Resources;
using Newtonsoft.Json.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Text;

namespace AutomationQlahsVksndtcWindowsFormsApp
{

    class ThuLyPopUp : Page
    {
        #region Controls definition  

        ComboBox loaiThuLy;
        //TextBox quyetĐinhKhoiToVuAnSo;
        //TextBox dieuLuatVu;
        //DateTimePicker ngayQuyetDinhKhoiToVuAn;
        //Other ngayQd;
        //Other ngayQdMot;
        //Other toiVuKhong;
        //ComboBox coQuanRaQuyetDinh;
        //Other coQuanCongAn;
        //TextBox donViRaQuyetDinh;
        //TextBox tenVuAn;
        //TextBox maVuCuaToaAn;
        //ComboBox loaiToiPhamB;
        //CheckBox loaiToiPhamC;
        //DateTimePicker ngayXayRa;
        //TextBox txtNgayXayRa;
        //TextBox thang;
        //TextBox nam;
        //TextBox gio;
        //TextBox noiXayRa;
        //TextBox chiTietNoiXayRa;
        //TextBox diaChiLuuTruHoSo;
        //TextBox ghiChu;
        //TextBox ngayQDKhoiToTuNgayText, ngayQDKhoiToDenNgayText, txtNgayQDKhoiToVuAn;

        //CheckBox ghiAmGhiHinhBiMat;
        //CheckBox ngheDienThoaiBiMat;
        //CheckBox thuThapBiMatDuLieuDienTu;

        Button ghiLaiTestThuLy;
        Button quayLai;
        Button capNhapThongTin, themMoiThuLy;
        TextBox thuLySo, ngayThuLy, thoiHanThuLyTuNgay, thoiHanThuLyDenNgay;
        TextBox maVuAnTestThuLy;
        Other lineData;

        //Other o;
        #endregion


        public ThuLyPopUp()
        {
            #region Controls initialize  
            loaiThuLy = new ComboBox("loại thụ lý", xpath.D["loaiThuLy"], "");
            thuLySo = new TextBox("thụ lý số", xpath.D["thuLySo"], "");
            maVuAnTestThuLy = new TextBox("mã vụ án", xpath.D["maVuAnTestThuLy"], "");
            ngayThuLy = new TextBox("thụ lý số", xpath.D["ngayThuLy"], "");
            thoiHanThuLyTuNgay = new TextBox("thụ lý số", xpath.D["thoiHanThuLyTuNgay"], "");
            thoiHanThuLyDenNgay = new TextBox("thụ lý số", xpath.D["thoiHanThuLyDenNgay"], "");
            lineData = new Other("dòng Data sau khi tìm kiếm", xpath.D["lineData"], "");
            ghiLaiTestThuLy = new Button("ghiLaiTestThuLy", xpath.D["ghiLaiTestThuLy"], "");
            quayLai = new Button("quay lại", xpath.D["tlBack"],"");
            capNhapThongTin = new Button("capNhapThongTin", xpath.D["capNhapThongTin"], "");
            themMoiThuLy = new Button("themMoiThuLy", xpath.D["themMoiThuLy"], "");
            //ngayQDKhoiToTuNgayText = new TextBox("txt ngày quyết định khởi tố", x.D["ngayQDKhoiToTuNgayText"], "");
            //ngayQDKhoiToDenNgayText = new TextBox("txt ngày quyết định khởi tố", x.D["ngayQDKhoiToDenNgayText"], "");
            //txtNgayQDKhoiToVuAn = new TextBox("text ngày quyết định khởi tố vụ án", x.D["txtNgayQDKhoiToVuAn"], "");
            //o = new Other();


            #endregion
            //x = new Xpath();
            //this.driver = driver; 
        }

        public void DienThongTin(JObject jVuAn)
        {
            //SendKeys("000632812", maVuAnTestThuLy);
            //Click(timKiem);
            //Click(lineData);
            //Click(capNhapThongTin);
            Click(themMoiThuLy);
            Click(loaiThuLy);
            SendKeys(jVuAn["loaiThuLy"].ToString(), loaiThuLy);
            SendKeys(Keys.Enter, loaiThuLy);
            Click(thuLySo);
            SendKeys(jVuAn["thuLySo"].ToString(), thuLySo);
            //SendKeys("1", thuLySo);
            Click(ngayThuLy);
            SendKeys(jVuAn["ngayThuLy"].ToString(), ngayThuLy);
            Click(thoiHanThuLyTuNgay);
            SendKeys(jVuAn["thoiHanThuLyTuNgay"].ToString(), thoiHanThuLyTuNgay);
            //SendKeys("10102019", ngayThuLy);
            Click(thoiHanThuLyDenNgay);
            SendKeys(jVuAn["thoiHanThuLyDenNgay"].ToString(), thoiHanThuLyDenNgay);
            //SendKeys("11112019", thoiHanThuLyDenNgay);
            Click(ghiLaiTestThuLy);
            Click(quayLai);
            Sleep();
            Sleep();
        }
    }
}
